#!/bin/bash

BASE_PATH=`dirname $0`
cd $BASE_PATH
java -Dfile.encoding=UTF-8 -Dsun.jnu.encoding=UTF-8 -jar starter.jar &